It is assumed that Priorview will be "installed" and thus run from the user's /Applications directory.

If Priorview is run from any other directory, it will fail.

After successfully launching Prioview, no HTML file will be created in the OmegaT project target directory until a change is made and a new "Create Translated Documents" is run (cmd-D or under Project -> Create Translated Documents).

Once this has been done, you can launch your preferred browser (see HowTo) and then drag and drop the HTML file created above into the browser window to begin viewing your translated file output.