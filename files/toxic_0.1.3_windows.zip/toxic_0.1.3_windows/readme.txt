TOXIC utility

2009-06-11
v. 0.1.3

Changes since 0.1.2:
--------------------
Graphical user interface added
Binary packages available 

Changes since 0.1.1:
--------------------
Standard OmegaT HTML filter now used (with thanks to Didier Briel)
Description of usage amended

Changes since 0.1.0:
--------------------
Bug corrected which prevented the use of the "&" character in target segments
Bug corrected which prevented use with ttx files containing xml comments
Improved command-line launching


All code in the Toxic utility written by Marc Prior can be found in the scripts version of the utilty, which can be downloaded from www.omegat.org/resources.html. Compiled binaries are provided for convenience only. The binaries were compiled using freeWrap, see: freewrap.sourceforge.net.


Copyright (C) 2009, Marc Prior

This program is free software; you may redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License (GPL) for more details.

A copy of the GNU General Public License should be available from the source from which you obtained this program; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

Marc Prior
lin4trans@users.sourceforge.net
www.marcprior.de


Purpose
-------
"Toxic" stands for Trados-OmegaT-eXchange. The purpose of the Toxic utility is to enable users of OmegaT to receive and deliver files in the Trados Tag Editor TTX format. Tradox TTX files are produced in Trados from a number of initial source-text formats. Toxic should therefore extend the range of file formats that can be handled in OmegaT. In addition, it enables OmegaT to be used in customer workflows which require Tag Editor.


Description
-----------
Toxic is a set of tcl/tk scripts. The tox script converts Trados TTX files to an intermediate format (the TOX format). This format in turn can be handled by OmegaT's existing HTML filter. After translation, the detox script is used to convert the TOX file back to TTX. The TOX format is unique to Toxic utility and is not designed to be read by any other application (although it is intended to follow XML conventions as far as possible).


Package
-----------
The Toxic package contains the following files:

readme.txt (this text file)
gpl.txt (the GNU Public License)
toxic.tcl (the toxic command-line script)
toxicui.tcl (the toxic script with user interface)
toxic (Linux binary)
toxic.exe (Windows executable)


Requirements
------------
Toxic is supplied both as standalone executables for Windows and Linux, and in the form of tcl/tk scripts.

The executables should run on Windows (95 onwards) and Linux respectively without the need for any further software.

The tcl/tk script versions require tcl/tk to be installed. Any current version of tcl/tk is likely to be adequate. Tcl/tk is available for Linux, Windows and Mac OSX, and is likely to be already installed on Linux and Mac OSX systems. Mac OSX users should install tcl/tk from their system media if it is not already installed. Windows users (and Linux users who do not wish to use their own distribution's tcl/tk installation) can use the ActiveTcl package available from www.activestate.com.


Registering the TOX format with the HTML filter
-----------------------------------------------
TOX files produced by Toxic 0.1.3 can be translated using OmegaT's existing HTML filter; a special build of OmegaT with a dedicated filter is no longer required.

TOX format files must however be registered with the HTML filter as follows. In OmegaT, select:

Options > File Filters > HTML and XHTML Files > Edit > Add

In the "Source Filename Pattern" box, change *.* to *.tox

Set "Source File Encoding" to "UTF-16" and "Target File Encoding" to <auto>.

Confirm with OK.

In "Options", check that "Add or rewrite encoding declaration in HTML and XHTML files" is NOT set to "Always". (If you need this setting for HTML and XHTML files, reset it after processing TOX files.)

Confirm again with OK.


Usage (Linux or Windows binary/executable)
------------------------------------------
Launch the binary/executable file. 

Hit "Tox", then select a TTX file to convert.

The TOX format file that is produced can then be translated in OmegaT.

After translation, convert the TOX file back to TTX. During conversion to TTX, the extension .exp is added to the TTX file. Delete this extension before opening the translated TTX file in Tag Editor or delivering to your customer. (This extension is added to prevent the translated TTX file from overwriting the original, untranslated TTX file, should the latter still be in the same folder.)


Usage (toxicui.tcl script)
----------------------
On the command line, execute

wish toxicui.tcl

The procedure is then the same as for the binary/executable.


Usage (toxic.tcl script)
----------------------
To convert a TTX file to TOX format:

Place the TTX file in the directory containing the Toxic script.

Open a command-line window and navigate to this directory.

Convert the ttx file to tox format with:

wish toxic.tcl tox filename.ttx

substituting "filename.ttx" with the name of the file. If the file contains spaces, enclose it in quotes. The toxic.tcl script (unlike the binaries and toxicui.tcl) supports batch processing, i.e. you can convert several files with a single command simply by listing them.

The name of your wish command may vary according to the distribution, e.g. wish85.

The TOX format file that is produced can then be translated in OmegaT.

To convert the TOX file back to TTX after translation, follow the same procedure but execute:

wish toxic.tcl detox filename.tox

Depending upon your system configuration, if you edit the first line of script to point to the location of your wish binary, you may be able to dispense with the "wish" in the command.

The detox script adds the extension ".exp" to the TTX filename; remove this extension before opening the TTX file in Tag Editor or delivering it to your customer.


Creating TTX files in Trados
----------------------------
Create a TTX file in Trados as follows:

1. Open Translator Workbench;
2. Go to Tools > Translate;
3. Check the box "Segment unknown sentences";
4. Click "Add..." and choose the ttx file;
5. Click "Translate". 


Issues
------
The script is VERY primitive. Test carefully before using on "real" jobs. Test by using the script + filter to translate sample TTX files and having a Trados TTX user verify that the final files are in order. It is also advisable to test roundtripping before completing new jobs, i.e. by completing the whole procedure but only translating a few sample sentences, to ensure that conversion is flawless.

Trados TTX files come in several forms. Toxic assumes that source and target segments are present and are identical. The TTX file may however not contain target segments, or they may be empty, or they may be "pretranslated", i.e. the target segments may already be partially translated. Toxic does not, at present, handle any of these scenarios.

Successive inline tags are reduced to a single placeholder tag. This simplifies the task of translating, but as a result there is therefore no means of separating formatting boundaries or changing their order. For example, if the text contains two words in both bold and italic, it is not possible to format the first in bold only, the second in italic only (as would be possible for an OOo file in OmegaT, for instance), nor can a bold span followed by an italic span be reversed.

The script may trip up over angle brackets in the text of segments.


Technical description
---------------------
The Trados TTX format is an intermediate format for the translation of a range of source text formats. TTX is XML, UTF-16 encoding, and begins with a byte-order mark. It contains source and target language segments and the formatting of the original source file.

Toxic works basically as follows:

The target-text segments (the content of which initially is identical to that of the source-text segments) are extracted and replaced by placeholders. In turn, inline formatting is extracted from the target-text segments and likewise replaced by placeholders. The arrays of placeholders/target segments and placeholders/inline formatting strings are appended at the end of the file. The TOX file thus consists of three parts (in the following order):

(1) The original TTX body, but with placeholder tags in place of the target segments
(2) An array of inline formatting strings and their placeholders
(3) An array of target segments (in which the inline formatting strings have been replaced by placeholders) and their placeholders

