import sys

def safestring(s):
    return (s.replace("<", "&lt;")).replace(">", "&gt;")

fonto=file(r"D:\fonto.txt", "r")
tradukajxo=file(r"D:\tradukajxo.txt", "r")
ftxt=fonto.readlines()
fonto.close()
ttxt=tradukajxo.readlines()
tradukajxo.close()
fntlng ="EN-US"
cellng = "BE-BY"

if len(ftxt) != len(ttxt):
    print("Error! Paragraph quantities in source and target texts do not match - unable to proceed")
    sys.exit(0)

tmxfile=file(r"D:\tmx.tmx", "w")
tmxfile.write(r'<?xml version="1.0" encoding="UTF-8"?>' + "\n" + r'<!DOCTYPE tmx SYSTEM "tmx11.dtd">' + "\n" + r'<tmx version="1.1">' + "\n" + r"  <header" + "\n" + r'    creationtool="org.omegat.OmegaT"' + "\n" + r'    creationtoolversion="1"' + "\n" + r'    segtype="paragraph"' + "\n" + r'    o-tmf="org.omegat.OmegaT TMX"' + "\n" + r'    adminlang="' + fntlng +'"' + "\n" + r'    srclang="' + fntlng +'"' + "\n" + r'    datatype="plaintext"' + "\n" + r'  >' + "\n" + r'  </header>' + "\n" + r'  <body>' + "\n")

for x in ftxt:
    if x.isspace():
        pass
    elif x.strip() == ttxt[(ftxt.index(x))].strip():
        pass
    else:
        tmxfile.write(r'    <tu>' + "\n" + r'      <tuv lang="' + fntlng + r'">' + "\n" + r'        <seg>' + safestring(x.strip()) + r'</seg>' + "\n"+ r'      </tuv>' + "\n" + r'      <tuv lang="' + cellng + '">' + "\n"+ r'        <seg>' + safestring(ttxt[(ftxt.index(x))].strip()) + r'</seg>' + "\n" + r'      </tuv>' + "\n" + r'    </tu>' + "\n")

tmxfile.write(r'  </body>' + "\n" + r'</tmx>')
tmxfile.close()
print("Finished")

