Extspell 1.1.4

See extspell.tcl for licence.

CHANGES:


v. 1.1.4
Selected text automatically assumed to be UTF-8.

v. 1.1.1
"Lock" function added. 
Support for multiple dictionaries with GUI selection added.
Primary/clipboard selection option added (Linux only).
Defaults file created for easier user modification of default values.

v. 1.0.1
Tcl/Tk native primary selection handler used instead of external xclip utility
Scrollbar added

REQUIREMENTS

* Aspell. Aspell is a standalone spelling checker. Linux and Windows versions are available, and it is supplied with many Linux distributions. Linux distributions not providing Aspell are likely to provide Ispell instead; this code could quite possibly be modified to use Ispell or for that matter other standalone spelling checkers, but I haven't tried this.
* Tcl/Tk.
* Operating system: any operating system supporting tcl/tk and Aspell. 

Aspell is available from: http://aspell.net/
Tcl/Tk is available from:http://www.tcl.tk/

After installing Aspell and Tcl/Tk, Windows users must place extspell.bat and extspell.tcl in the folder containing the file aspell.exe (extspell\bin).

GENERAL

Extspell is an external spelling checker utility. It provides a text area into which text can be copied, where it is then spell-checked.

Extspell is released under the OmegaTk project. The purpose of the OmegaTk project is to encourage translators to learn to program. As a by-product of the project, it is hoped that code will become available which will support the users and/or developers of the OmegaT translation memory application.

This code is therefore intended for people - particularly translators - who are learning Tcl/Tk. If you are an end user with no knowledge of Tcl/Tk, you are perfectly entitled to use it, but if it doesn't work, please consider learning Tcl/Tk, and modifying it yourself. That's what the OmegaTk sub-project is all about.

Extspell was originally intended to provide an in-line spelling checker for OmegaT. It can however be used as an in-line spelling checker for other applications.

USAGE

Launching:
Execute the file extspell or extspell.bat.

This launches the Tcl/Tk interpreter which raises an empty Extspell window. When the focus changes to the Extspell window, the content of the primary selection appears in it, and any misspelled words are highlighted. To spell-check, just copy the text you want to check to the clipboard, then switch back to the Extspell window. The copied text does not need to be pasted into the Extspell window.

Mis-spelled words are highlighted and can then be corrected manually in the original application. Extspell does not correct any spelling errors automatically or make suggestions for their correction.

Lock function:
This function freezes the content of the Extspell window. This is useful for spell-checking of a longer block of text, as it enables the user to toggle between the Extspell window (which may need to be scrolled) and the window in which text is to be edited. If the lock is disabled, the content of the Extspell window inevitably changes when the user makes editing changes in the application window which affect the primary/clipboard selection.
The lock function enables OmegaT users to spell-check whole documents at once by marking the whole content (with the mouse) of the main OmegaT window.

Primary/clipboard selection handler:
For Linux users who wish to use the primary selection (recommended) instead of/as well as the clipboard.

Dictionary selection:
Extspell can be used with any installed Aspell dictionaries (at the time of writing, dictionaries are available for over seventy languages). Simply select the desired dictionary under "Language". The default Aspell dictionary serves as the default, unless a different default dictionary is specified in the defaults file.


ISSUES

My programming skills. :-)

It seems to work (on my configuration, see above), which is a minor miracle.

Various applications behave differently with regard to their primary selection. In some cases the primary selection is not passed if Ctrl-A is used. Mark with other keyboard shortcuts or the mouse in this case. In others, it is not passed if the user tabs to the Extspell window to give it focus; click in the Extspell window with the left-hand mouse button in this case.

As far as I can see, there is no need for OmegaT markup tags to be handled specially; Aspell recognizes that these are not part of the word. Extspell can therefore probably also be used to check HTML code etc.

Extspell does not highlight mis-spelled words as such, but strings which Aspell flags as mis-spelled words. This means that if "mou" is typed instead of "mouse", all instances of "mou" will be highlighted, even within the properly spelled word "mouse". I am looking for a solution to this but haven't yet found one.

Marc Prior
www.marcprior.de
