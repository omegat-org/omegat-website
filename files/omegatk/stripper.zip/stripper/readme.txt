Stripper script

1. Introduction

The stripper script can be used to extract lines of translatable text from plain-text or other human-readable files. Where translatable text matches a certain pattern, e.g. is preceded/followed by a certain marker string, this string can be used to mark the lines concerned for translation. All other lines will be deleted, leaving only relevant lines for translation, e.g. in OmegaT. The remaining lines can then be merged back in again easily once translation is complete.

The script can handle multiple search strings and multiple files simultaneously.

The script is an alternative to (for example) using OmegaT's regular expression function to find translatable text portions within computer code.

2. License comments

Written by Marc Prior, 2008.
Use ENTIRELY AT YOUR OWN RISK!

3. Requirements

The stripper script requires tcl/tk. Any version of tcl/tk should be adequate. Tcl/tk is available from:

www.tcl.tk/software/tcltk/

4. Usage

On the command line:

wish stripper {arguments}

The script accepts filenames as arguments. If no arguments are stated, the script processes all files in the present working directory that meet the glob pattern in the script. (Note: if file names contain spaces, enclose them in quotes.)

When run, the script:

1. Creates copies of all the files matching the pattern, with the name stripped_<filename>.
2. In the copies of the files, the script retains the lines containing the strings specified in the script and deletes all other lines.
3. In addition, lines following lines containing the strings are inserted when a line continuation string is matched.

To use the script to translate files in OmegaT:

1. Modify the script:

- Insert the strings marking translatable text
- Modify the line continuation string. This is the string used in computer code to denote that the line continues on the next line. (If the files for translation are known not to contain broken lines, enter an improbable string as the line continuation string.)
- Modify the glob pattern for the files if necessary.

2. Copy the script to the directory containing the files to be translated, and run it (see above).

3. Create an OmegaT project. Copy the stripped_ files into /source. If necessary, change the file extensions (e.g. to .txt). Translate the project. Save and create the target documents. 

4. Copy the original ("unstripped") files into /source. If necessary, change the file extensions. Reload the OmegaT project, save and create the target documents.

5. Change the file extensions of the translated file back if necessary.
