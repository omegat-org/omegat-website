﻿#!/usr/bin/perl -w

# Alignment tool
$version="0.4.5";
# Creates a TMX file, based on a source and a target file
# Based initially on aligner.py by Dmitri Gabinski 
# Copyright (C) Didier Briel 2005-2011
# bligner is licensed under the Artistic License 2.0

# Texts modified in this file (especially expressions for segmenting or not)
# must be entered in a utf-8 compatible editor

# Configuration variables

# Interactive mode
# y = interactive
# n = no
#$interactive = "y";
$interactive = "n";
# If not in interactive mode, source, target and Tmx file
# can be specified below

# Source file
$fsourcename = "source.txt";
# Target file
$ftargetname = "target.txt";
# Tmx file
$ftmxname = "tmx.tmx";
# Log file
$flog = "log.txt";

# Source language
$lngsource = "EN";
# Target language
$lngtarget = "FR";
# Admin language
$lngadmin = "EN-US";

# Segmentation
# p = paragraph
# s = sentence
#$segmenttype = "p";
$segmenttype = "s";

# Following expressions should not segment (in case of segment="s").
# Each expressions is entered between "[" and "]", followed by a comma (",") 
# except for the last one.
# ".", "?" and "|" must be prefixed with a "\" 
# The following presets are the same as the default ("*.") 
# in OmegaT (version 1.6 RC7)
@anosegment = (
                ['\.\.\.', '\s+\P{Lu}'],
                ['etc\.', '\s+\P{Lu}'],
                ['Dr\.', '\s'],
                ['U\.K.', '\s'],
                ['M\.', '\s'],
                ['Mr\.', '\s'],
                ['Mrs\.', '\s'],
                ['Ms\.', '\s'],
                ['Prof\.', '\s'],
                ['(?i)e\.g\.', '\s'],
                ['(?i)i\.e\.', '\s'],
                ['resp\.', '\s'],
                ['tel\.', '\s'],
# You can modify the preset, or simply uncomment (deleting the #)
# an abbreviation to add it to the list of expressions
#                ['U\.S.', '\s'],
                ['Tel\.', '\s'],
                ['a\.m\.', '\s'],
                ['p\.m\.', '\s'],
                ['Misc\.', '\s'],
                ['autom\.', '\s'],
# Some German abbreviations
#                ['bzgl\.', '\s'], 
#                ['bzw\.', '\s'],
#                ['allg\.', '\s'],
#                ['Nr\.', '\s'],
#                ['s\.o\.', '\s'],
#                ['s\.\su\.', '\s'],
#                ['u\.a\.', '\s'],
#                ['u\.\sa\.', '\s'],
#                ['u\. a\.', '\s'],
#                ['z\.\sB\.', '\s'],
#                ['z\. B\.', '\s'],
#                ['d\. h\.', '\s'],
#                ['d\.\sh\.', '\s'],
#                ['ggf\.', '\s'],
#                ['Std\.', '\s'],
#                ['evtl\.', '\s'],
#                ['usw\.', '\s'],
# Some French abbreviations
#                ['N\.B\.', '\s'],
#                ['c\.-à-d\.', '\s'],
#                ['c\.à\.d\.', '\s'],
#                ['av\.', '\s'],
#                ['ex\.', '\s'],
#                ['env\.', '\s'],
#                ['Tél\.', '\s'],
# Specific case (no segment on sentence such as: 'you can use " ? " as a wildcard')
                ['"\s\?', '\s"']
               );

# Following expressions should segment (in case of segment="s")
# ".", "?" and "|" must be prefixed with a "\" 
@asegment = (
             ['[\.\?!]', '\s']
            );

# end of configuration variables

sub safestring 
{
    local ($s) = @_;
    
    for($s)
    {
       s/&/&amp;/g;
       s/</&lt;/g;
       s/>/&gt;/g;
       s/"/&quot;/g;
	   s/[\x00-\x08]|\x0B|\x0C|[\x0E-\x1F]//g;
    }

    return $s;
}

sub writeline
{
 local ($tsource) = &safestring($prtlsource);
 local ($ttarget) = &safestring($prtltarget);
 
    print FTMX <<END;
    <tu>
      <tuv lang="$lngsource">
        <seg>$tsource</seg>
      </tuv>
      <tuv lang="$lngtarget">
        <seg>$ttarget</seg>
      </tuv>
    </tu>
END
}

sub strip
{
    local ($s) = @_;
    
    for ($s)
    {
		s/^\s+//;
		s/\s+$//;
    }
    return $s;
}

# Source file
if ($interactive eq "y")
{
    print "Enter source file name: ";
    chomp($fsourcename = <STDIN>);
}
open(FSOURCE, $fsourcename) || die("No source file") ;

# Target file
if ($interactive eq "y")
{    
    print "Enter target file name: ";
    chomp($ftargetname = <STDIN>);
}
open (FTARGET, $ftargetname) || die("No target file");

@lsource = <FSOURCE>;
close FSOURCE;
@ltarget = <FTARGET>;
close FTARGET;

open (FLOG, ">$flog");

$warning = 0;

if (@lsource != @ltarget)
{
    $errortext = "Error! Paragraph quantities in source and target texts do not match\n" .
                 "- unable to proceed -\n" .
                 "Source paragraphs : " . (@lsource) . "\n" .
                 "Target paragraphs : " . (@ltarget) . "\n";
    print $errortext;
    print "Press Return to quit";
    print FLOG $errortext;
    close FLOG;
    <STDIN>;
    exit(0);
}

print "Aligner, processing text\n";

# Tmx file
if ($interactive eq "y")
{
    print "Enter tmx file name: ";
    chomp($ftmxname = <STDIN>);
}
open (FTMX, ">$ftmxname") || die("No TMX file");;

if ($segmenttype eq "s") 
{
    $segtype="sentence";
}
else 
{
    $segtype="paragraph";
}
    
print FTMX <<BEGIN;
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE tmx SYSTEM "tmx11.dtd">
<tmx version="1.1">
  <header
    creationtool="bligner.pl"
    creationtoolversion="$version"
    segtype="$segtype"
    o-tmf="org.omegat.OmegaT TMX"
    adminlang="$lngadmin"
    srclang="$lngsource"
    datatype="plaintext"
  >
  </header>
  <body>
BEGIN

if ($segmenttype eq "s") #Prepare segmentation lists
{
	$num = @asegment;
	$split = "";
	for ($x=0; $x < $num; $x++)
	{
	  $split .= '(?:'.$asegment[$x][0].$asegment[$x][1].')';
	  if ( $x < $num - 1) # Not the last one
	  {
		$split .='|';
	  }
	}    
}


$index = -1;
foreach $paragraph (@lsource)
{
    $index++;
       
    next if ( !($paragraph) ); # Empty paragraph
    next if ($paragraph eq $ltarget[$index]); # Source and target are equal

	$paragraph = &strip($paragraph);
	$ltarget[$index] = &strip($ltarget[$index]);

    if ($index==0) # Remove potential BOM on first segment
    { 
        $paragraph =~ s/\xEF\xBB\xBF//; 
        $ltarget[$index] =~ s/\xEF\xBB\xBF//; 
    }

	if ($segmenttype eq "s")
	{
	    $savparagraph = $paragraph;
	    $savtarget = $ltarget[$index];
	    
		# Apply list of exceptions
		$num = @anosegment;
		for ($x=0; $x < $num; $x++)
		{
		    $except = $anosegment[$x][0];
		    $exceptsafe = $except;
		    if ($except =~ m/\\s/) # \s in pattern
		    {
				$exceptsafe =~ s/\\s/WHITESPACE/g;
				while ($paragraph =~ /$except/)
				{
					$replace = $&;
					$replace =~ s/\s/WHITESPACE/g;
					$paragraph =~ s/$except/$replace/;
				}
				while ($ltarget[$index] =~ /$except/)
				{
					$replace = $&;
					$replace =~ s/\s/WHITESPACE/g;
					$ltarget[$index] =~ s/$except/$replace/;
				}
			}
			$after = $anosegment[$x][1];
		    $paragraph =~ s/($exceptsafe)($after)/$1NOSEGMENT$2/g;
		    $ltarget[$index] =~ s/($exceptsafe)($after)/$1NOSEGMENT$2/g;
		} 		

		# Double split points, so that they remain after the split
		$num = @asegment;
		for ($x=0; $x < $num; $x++)
		{
			$segment = '(' . $asegment[$x][0] . ')(' .$asegment[$x][1] .')';
			if ($asegment[$x][1] eq '\s')
			{
			  $paragraph =~ s/$segment/$1$1$2/g;
			  $ltarget[$index] =~ s/$segment/$1$1$2/g;
			}
			else
			{
			  $paragraph =~ s/$segment/$1$1$2$2/g;
			  $ltarget[$index] =~ s/$segment/$1$1$2$2/g;
			}
		}
	
		# Split paragraph
		@ssource = split(/$split/, $paragraph);
		@starget = split (/$split/, $ltarget[$index]);
		
		if (@ssource != @starget)
		{
			print FLOG 
				"Warning: Number of sentences in source and target text does no match in the following paragraph:\n".
				"***Source text: " . @ssource . " sentence(s)****\n" .
				$savparagraph . "\n" . 
				"***Target text: " . @starget . " sentence(s)****\n" .
				$savtarget . "\n" . 
				"***Some translations might be lost***\n\n";
			$warning = 1;    
		}
		
		if (@ssource > @starget)
		{
		    $max = @ssource;
		}
		else
		{
		    $max = @starget;
		}
		
		for ($sindex=0; $sindex < $max; $sindex ++)
		{
			if ($sindex > @ssource-1) # Source sentence does not exist
			{
			    $prtlsource .= "[$sindex]";
			}
			else
			{
			    $prtlsource = $ssource[$sindex];
			}
			if ($sindex > @starget-1) # Target sentence does not exist
			{
			    $prtltarget .= "[$sindex]";
			}
			else
			{
			    $prtltarget = $starget[$sindex];
			} 
        	        	
			# Restore list of exceptions
		    $num = @anosegment;
		    for ($x=0; $x < $num; $x++)
		    {
				$except = $anosegment[$x][0];
				$exceptsafe = $except;
				if ($except =~ m/\\s/) # \s in pattern
				{
					$exceptsafe =~ s/\\s/WHITESPACE/g;
					while ($prtlsource =~ /$exceptsafe/)
					{
						$replace = $&;
						$replace =~ s/WHITESPACE/ /g;
						$prtlsource =~ s/$exceptsafe/$replace/;
					}
					while ($prtltarget =~ /$exceptsafe/)
					{
						$replace = $&;
						$replace =~ s/WHITESPACE/ /g;
						$prtltarget =~ s/$exceptsafe/$replace/;
					}
				}
			    $after = $anosegment[$x][1];
			    $prtlsource =~ s/($except)NOSEGMENT($after)/$1$2/g;
			    $prtltarget =~ s/($except)NOSEGMENT($after)/$1$2/g;
			}			

			if ($prtlsource ne $prtltarget)
			{
				&writeline;
		    }
		} # foreach $oneline
	} # if $segmenttype eq "s"
	else 
	{
	    $prtlsource = $paragraph;
	    $prtltarget = $ltarget[$index];
	    &writeline;
	}
    
} # foreach $paragraph (@lsource)

print FTMX <<END;
  </body>
</tmx>
END

close FTMX;
close FLOG;

print("End of processing\n");

if ($warning == 1)
{
    print("There were warnings. Check log file " . $flog . "." . "\n");
    print("Press Return to quit");
    <STDIN>;
}