Icons for OmegaT


LICENCE (1)

The following icons are the work of Nacho Carretero:

OmegaT_IconA_outline.png
OmegaT_IconC_hollow.svg
OmegaTSplash2.png
OmegaT_IconB.png
OmegaT_Icon.png
OmegaT_IconC_hollow.png
OmegaTSplash1.png

The icons listed above are free software; you may redistribute them and/or modify them under the terms of the GNU General Public License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.

These icons are distributed in the hope that they will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License (GPL) for more details.

A copy of the GNU General Public License should be available from the source from which you obtained this program; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

The icons in this package are subject to ABSOLUTELY NO WARRANTY.
This is free software, and you are welcome to redistribute it under certain conditions; please refer to the GPL for details.


LICENCE (2)

The following icons are the work of Marc Prior, and are deemed to be in the public domain:

icon10a.gif
icon11.sxd
icon9.xpm
relOT12.png
relOT15.png
relOT19.png
icon10.sxd
icon9.gif
relOT13.png
relOT17.png
testicon.png
icon11.gif
icon9.sxd
relOT11.png
relOT14.png
relOT18.png

The icons listed above are subject to ABSOLUTELY NO WARRANTY.


USAGE

Convert to GIF format (if not already). Save as OmegaT_small.gif and OmegaT.gif. For best results, OmegaT_small.gif and OmegaT.gif should be approximately 16x16 and 32x32 pixels respectively. Copy the icons to the \images folder of your OmegaT installation.
