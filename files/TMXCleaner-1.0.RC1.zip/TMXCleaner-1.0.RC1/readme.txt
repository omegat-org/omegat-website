TMXCleaner-1.0.RC1.jar

TMXCleaner is a Java command-line script for removing "superfluous" translation units from a TMX file: deletes all TUs without target segment or in which the target segment is identical to the source segment.

Installation:

Place the file TMXCleaner-1.0.RC1.jar in any desired folder. Java must be installed on your system.

Usage:

TMXCleaner-1.0.RC1.jar must be executed on the command line.

The command to execute TMXCleaner-1.0.RC1.jar has the following form:

java -jar TMXCleaner-1.0.RC1.jar <filename>

Where <filename> is the name of the file to be cleaned.
