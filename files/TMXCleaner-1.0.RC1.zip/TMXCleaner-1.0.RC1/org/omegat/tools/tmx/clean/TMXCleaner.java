/*
 * TMXCleaner - Strips TUs without target segments
 * Copyright(c) 2005, Henry Pijffers (henry.pijffers@saxnot.com)
 * 
 * This program is licensed to you under the terms of version 2
 * of the GNU General Public License, as published by the Free
 * Software Foundation
 */

package org.omegat.tools.tmx.clean;

import java.util.ArrayList;

/**
  * Strips TUs without target segments from a TMX file.
  * TUs that have an identical source and target segment
  * are considered not to have any target segments.
  *
  * @author Henry Pijffers (henry.pijffers@saxnot.com)
  */
public class TMXCleaner {

    public static void main(String[] arguments) {
        // FIX: check arguments
        
        // check number of arguments
        if (arguments.length != 1) {
            // print usage info
            System.err.println("Usage: TMXCleaner <filename>");
            
            // halt program
            return;
        }
        
        try {
            // load the TMX file
            TMX tmx = new TMX();
            tmx.load(arguments[0], true);
            
            // save the merged TMX to the file specified in the last argument
            // FIX: check if the file already exists, and ask for permission to overwrite
            String filename = arguments[0].substring(0, arguments[0].lastIndexOf('.'));
            tmx.save(filename + "-clean.tmx");
        }
        catch (java.io.IOException exception) {
            System.err.println(exception.getLocalizedMessage());
            exception.printStackTrace(System.err);
        }
    }

}
