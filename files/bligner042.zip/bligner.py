#!/usr/bin/env python
# -*- coding: utf-8 -*-

# Alignment tool for OmegaT
version = "0.4.1"
# Creates a Tmx file, based on a source and a target file
# Original version (aligner.py) by Dmitri Gabinski 
# Modifications in Python by Didier Briel (bligner.py)
# Modifications in Perl by Didier Briel (bligner.pl)
# Texts modified in this file (especially expressions for segmenting or not)
# must be entered in a utf-8 compatible editor

import sys
import re
from tkFileDialog import *

# Configuration variables

# Interactive mode
# y = interactive
# n = no
interactive = "y"
#interactive = "n"
# If not in interactive mode, source, target and Tmx file
# can be specified below

# Source file
fsourcename = r"source.txt"
# Target file
ftargetname = r"target.txt"
# Tmx file
ftmxname = r"tmx.tmx"
# Log file
flog = file(r"log.txt", "w")

# Source language
lngsource = "EN"
# Target language
lngtarget = "FR"
# Admin language
lngadmin = "EN-US"

# Segmentation
# p = paragraph
# s = sentence
#segmenttype = "p"
segmenttype = "s"

# Following expressions should not segment (in case of segment="s").
# Each expressions is entered between "[" and "]", followed by a comma (",") 
# except for the last one.
# ".", "?", "|", "(" and ")" must be prefixed with a "\" 
# The following presets are the same as the default ("*.") 
# in OmegaT (version 1.6 RC7)
anosegment = [
#               ['\.\.\.', '\s+\P{Lu}'],
               ['\.\.\.', '\s+[^A-Z]'], # \P syntax doesn't seem to work in Python
#               ['etc\.', '\s+\P{Lu}'],
               ['etc\.', '\s+[^A-Z]'], # \P syntax doesn't seem to work in Python
               ['Dr\.', '\s'],
               ['U\.K.', '\s'],
               ['M\.', '\s'],
               ['Mr\.', '\s'],
               ['Mrs\.', '\s'],
               ['Ms\.', '\s'],
               ['Prof\.', '\s'],
               ['(?i)e\.g\.', '\s'],
               ['(?i)i\.e\.', '\s'],
               ['resp\.', '\s'],
               ['tel\.', '\s'],
# You can modify the preset, or simply uncomment (deleting the #)
# an abbreviation to add it to the list of expressions
#               ['U\.S.', '\s'],
                ['Tel\.', '\s'],
                ['a\.m\.', '\s'],
                ['p\.m\.', '\s'],
                ['Misc\.', '\s'],
                ['autom\.', '\s'],
# Some German abbreviations
#                ['bzgl\.', '\s'], 
#                ['bzw\.', '\s'],
#                ['allg\.', '\s'],
#                ['Nr\.', '\s'],
#                ['s\.o\.', '\s'],
#                ['s\.\su\.', '\s'],
#                ['u\.a\.', '\s'],
#                ['u\.\sa\.', '\s'],
#                ['u\. a\.', '\s'],
#                ['z\.\sB\.', '\s'],
#                ['z\. B\.', '\s'],
#                ['d\. h\.', '\s'],
#                ['d\.\sh\.', '\s'],
#                ['ggf\.', '\s'],
#                ['Std\.', '\s'],
#                ['evtl\.', '\s'],
#                ['usw\.', '\s'],
# Some French abbreviations
#                ['N\.B\.', '\s'],
#                ['c\.-à-d\.', '\s'],
#                ['c\.à\.d\.', '\s'],
#                ['av\.', '\s'],
#                ['ex\.', '\s'],
#                ['env\.', '\s'],
#                ['Tél\.', '\s'],
# Specific case (no segment on sentence such as: 'you can use " ? " as a wildcard')
                ['"\s\?', '\s"']
              ];

# Following expressions should segment (in case of segment="s")
# ".", "?", "|", "(" and ")" must be prefixed with a "\" 
asegment = [
             ['[\.\?!]', '\s']
           ];


def safestring(s):
    return (s.replace("<", "&lt;")).replace(">", "&gt;")

def writeline():
    ftmx.write(r'    <tu>' + "\n" + \
               r'      <tuv lang="' + lngsource + r'">' + "\n" + \
               r'        <seg>' + safestring(prtlsource) + r'</seg>' + "\n" + \
               r'      </tuv>' + "\n" + \
               r'      <tuv lang="' + lngtarget + '">' + "\n" + \
               r'        <seg>' + safestring(prtltarget) + r'</seg>' + "\n" + \
               r'      </tuv>' + "\n" + \
               r'    </tu>' + "\n")


# Source file
if interactive == "y":
    fsourcename = askopenfilename(filetypes=[("Text files", "*.txt")])
    if not fsourcename:
        sys.exit(0)
fsource = file(fsourcename, "r")

# Target file
if interactive == "y":
    ftargetname = askopenfilename(filetypes=[("Text files", "*.txt")])
    if not ftargetname:
        sys.exit(0)    
ftarget = file(ftargetname, "r")

lsource = fsource.readlines()
fsource.close()
ltarget = ftarget.readlines()
ftarget.close()

warning = 0

if len(lsource) != len(ltarget):
    errortext = "Error! Paragraph quantities in source and target texts do not match\n" + \
                "- unable to proceed -\n" + \
                "Source paragraphs : " + str(len(lsource)) + "\n" + \
                "Target paragraphs : " + str(len(ltarget)) + "\n"
    print(errortext)
    print("Press Return to quit")
    flog.write(errortext)
    flog.close()
    input()
    sys.exit(0)

print("Aligner, processing text\n")

# Tmx file
if interactive == "y":
    ftmxname = asksaveasfilename(filetypes=[("TMX files", "*.tmx")])
    if not ftmxname:
        sys.exit(0)

if segmenttype == "s":
    segtype="sentence"
else:
    segtype="paragraph"
    
ftmx = file(ftmxname, "w")

ftmx.write(r'<?xml version="1.0" encoding="UTF-8"?>' + "\n" + \
           r'<!DOCTYPE tmx SYSTEM "tmx11.dtd">' + "\n" + \
           r'<tmx version="1.1">' + "\n" + \
           r"  <header" + "\n" + \
           r'    creationtool="bligner.py"' + "\n" + \
           r'    creationtoolversion="' + version + '"' + "\n" + \
           r'    segtype="' + segtype + '"' + "\n" + \
           r'    o-tmf="org.omegat.OmegaT TMX"' + "\n" + \
           r'    adminlang="' + lngadmin + '"' + "\n" + \
           r'    srclang="' + lngsource + '"' + "\n" + \
           r'    datatype="plaintext"' + "\n" + \
           r'  >' + "\n" + \
           r'  </header>' + "\n" + \
           r'  <body>' + "\n")

if (segmenttype == "s"): # Prepare segmentation lists
    ssplit = ""
    for x in range (len(asegment)):
        ssplit += '(?:' + asegment[x][0] + asegment[x][1] + ')'
        if ( x < (len(asegment) - 1)): # Not the last one
            ssplit +='|'
index = -1
for paragraph in lsource:
    
    index = index + 1
    
    if paragraph.isspace():
        pass
    elif paragraph.strip() == ltarget[(lsource.index(paragraph))].strip():
        pass
    else:
        paragraph = paragraph.strip()
        ltarget[index] = ltarget[index].strip()
        
        if segmenttype == "s":
            
            savparagraph = paragraph
            savtarget = ltarget[index]
            
            # Apply list of exceptions
            for x in range(len(anosegment)):
                exception = anosegment[x][0]
                exceptsafe = exception
                if ( re.search(r'\\s', exception) ): # \s in pattern
                    exceptsafe = re.sub(r'\\s', 'WHITESPACE', exception)
                    expression = re.compile(exception)
                    iterator = expression.finditer(paragraph)
                    for replace in iterator: 
                        replacestr = replace.group()
                        replacestr = re.sub(r'\s', 'WHITESPACE', replacestr)
                        paragraph = re.sub(exception, replacestr, paragraph)
                    iterator = expression.finditer(ltarget[index])
                    for replace in iterator: 
                        replacestr = replace.group()
                        replacestr = re.sub(r'\s', 'WHITESPACE', replacestr)
                        ltarget[index] = re.sub(exception, replacestr, ltarget[index])
                after = anosegment[x][1]
                paragraph = re.sub('(' + exceptsafe + ')(' + after + ')', r'\1NOSEGMENT\2', paragraph)
                ltarget[index] = re.sub('(' + exceptsafe + ')(' + after + ')', \
                                                         r'\1NOSEGMENT\2', \
                                                         ltarget[index])

            # Double split points, so that they remain after the split
            for x in range(len(asegment)):
                segment = '(' + asegment[x][0] + ')(' + asegment[x][1] + ')';
                if (asegment[x][1] == '\s'):
                    paragraph = re.sub(segment, r'\1\1\2', paragraph)
    	            ltarget[index] = re.sub(segment, r'\1\1\2', ltarget[index]);
                else:
                    paragraph = re.sub(segment, r'\1\1\2\2', paragraph)
    	            ltarget[index] = re.sub(segment, r'\1\1\2\2', ltarget[index]);
                 
            # Split paragraph
            ssource = re.split(ssplit, paragraph) 
            starget = re.split(ssplit, ltarget[index])
            
            if len(ssource) != len(starget):
                flog.write(\
                    "Warning: Number of sentences in source and target text does no match in the following paragraph:\n"+\
                    "***Source text: " + str(len(ssource)) + " sentence(s)****\n" + \
                    savparagraph + "\n" + \
                    "***Target text: " + str(len(starget)) + " sentence(s)****\n" + \
                    savtarget + "\n" + \
                    "***Some translations might be lost***\n\n")
                warning = 1

            maxl = max(len(ssource), len(starget))

            for sindex in range(maxl):
                try:
                    prtlsource = ssource[sindex]
                except IndexError:
                    prtlsource += '[' + str(sindex) + ']'
                    pass
                try:
                    prtltarget = starget[sindex]
                except IndexError:
                    prtltarget += '[' + str(sindex) + ']'
                    pass
                
                # Restore list of exceptions
                for x in range(len(anosegment)):
                    exception = anosegment[x][0]
		    exceptsafe = exception
                    if ( re.search(r'\\s', exception) ): # \s in pattern
                        exceptsafe = re.sub(r'\\s', 'WHITESPACE', exception)
                        expression = re.compile(exceptsafe)
                        iterator = expression.finditer(prtlsource)
                        for replace in iterator: 
                            replacestr = replace.group()
                            replacestr = re.sub('WHITESPACE', ' ', replacestr)
                            prtlsource = re.sub(exceptsafe, replacestr, prtlsource)
                        iterator = expression.finditer(prtltarget)
                        for replace in iterator: 
                            replacestr = replace.group()
                            replacestr = re.sub('WHITESPACE', ' ', replacestr)
                            prtltarget = re.sub(exceptsafe, replacestr, prtltarget)
                    after = anosegment[x][1]
                    prtlsource = re.sub('(' + exception + ')NOSEGMENT' + '(' + after + ')', r'\1\2', prtlsource)
                    prtltarget = re.sub('(' + exception + ')NOSEGMENT' + '(' + after + ')', r'\1\2', prtltarget)
                
                if prtlsource != prtltarget:
                    writeline()
        else:
            prtlsource = paragraph
            prtltarget = ltarget[index]
            writeline()

ftmx.write(r'  </body>' + "\n" + \
           r'</tmx>')

ftmx.close()
flog.close()

print("End of processing\n")

if warning == 1:
    print("There were warnings. Check log file " + flog.name + "." + "\n")
    print("Press Return to quit")
    input()
