import sys
from Tkinter import *
from tkFileDialog import *

def die():
    sys.exit(0)

if __name__ == "__main__":
    root=Tk()
    fnt=askopenfilename(filetypes=[("TMX files", "*.tmx")])
    if fnt:
        fonto=file(fnt, "r")
        ftxt=fonto.readlines()
        fonto.close()
        sname = asksaveasfilename(filetypes=[("TMX files", "*.tmx")])
        if sname:
            tmxfile=file(sname, "w")
            for x in ftxt:
                if "<?xml version=" in x:
                    tmxfile.write(r'<?xml version="1.0" encoding="UTF-8"?>' + "\n")
                elif r'<!DOCTYPE tmx SYSTEM "tmx11.dtd">' in x:
                    tmxfile.write(r'<!DOCTYPE tmx SYSTEM "tmx11.dtd">' + "\n")
                elif r'<tu ' in x:
                    tmxfile.write('<tu>' + "\n")
                elif r'creationdate="' in x:
                    pass
                elif r'creationid="' in x:
                    pass
                else:
                    tmxfile.write(x)
    
            tmxfile.close()
            print("Finished")
            die()
