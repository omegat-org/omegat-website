Note:

Inter alia, the mentioned Python script was written for WF 4.x translation memories and won't work with WF 5.x TMs, if they are in Unicode/UTF-16 (try converting them to UTF-8 with any good text editor first).
