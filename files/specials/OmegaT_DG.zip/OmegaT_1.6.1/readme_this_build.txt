This build is made by Dmitri Gabinski.
It's identical to the official OmegaT 1.6.0_02 build by its funcionality, but it's got more keyboard shortcuts:
- Ctrl+F2 to create a new project;
- Ctrl+F4 to close project;
- Ctrl+f5 to reload project;
- Ctrl+K to create translated documents;
- Ctrl+F6 to call file filter dialog;
- Ctrl+F7 to call segmentation dialog;
- Ctrl+F8 to call workflow dialog;
- Ctrl+F9 to call font dialog.
Enjoy!

The archive also includes two Python scripts to choose OmegaT GUI 
language on start. Please, note, that you'll probably need to modify 
the way to the Java executable.