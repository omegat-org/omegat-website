# -*- coding: utf-8 -*-

from Tkinter import *
import sys
import os

def die(event):
    global v, periods
    ul = "-server -Xmx256m -Duser.language="+ v.get() + " -jar OmegaT.jar"
    argums=(ul,)
    os.execv(r"D:\Program Files\Java\jre1.6.0\bin\java.exe", argums)
    sys.exit(0)

root = Tk()
button = Button(root)
button["text"] = "Lanĉu!"
button.bind("<Button>",die)
button.pack()

v = StringVar()
v.set("be")

periods = [
    ("Esperanto", "eo"),
    ("Беларуская", "be"),
    ("English", "en"),
    ("Русский", "ru"),
    ("Español", "es"),
    ("Français", "fr"),
    ("日本語", "ja"),
    ("Türkçe", "tr"),
    ("Deutsch", "de"),
    ("Italiano", "it"),
    ("Português", "pt"),
    ("Ελληνικά", "el"),
]

for t, m in periods :
    b = Radiobutton(root,text=t, variable=v, value=m)
    b.pack(anchor=W)

root.mainloop()
