//-------------------------------------------------------------------------
//  
//  OStrings.java - 
//  
//  Copyright (C) 2004, Keith Godfrey
//  
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//  
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//  
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//  
//  Copyright (C) 2004, Keith Godfrey, et al
//  keithgodfrey@users.sourceforge.net
//  907.223.2039
//  
//  OmegaT comes with ABSOLUTELY NO WARRANTY
//  This is free software, and you are welcome to redistribute it
//  under certain conditions; see 'gpl.txt' for details
//
//-------------------------------------------------------------------------

class OStrings {
/*
// TransPanel
public static final String TP_SRC_TEXT		= "Source Text:";
public static final String TP_TRANSLATION	= "Translation:";
public static final String TP_NUM_STRINGS	= "Number of strings:";
public static final String TP_CURRENT_STRING	= "Current string:";
public static final String TP_FILENAME		= "Filename:";
public static final String TP_UNIQUE_ID		= "String unique ID:";
public static final String TP_SEARCH		= "Search";
public static final String TP_SEARCH_KEYWORD	= "Keyword";
public static final String TP_SEARCH_EXACT	= "Exact";
public static final String TP_BUTTON_NEXT	= "Next";
public static final String TP_BUTTON_PREV	= "Previous";
*/
// MessageDialog
public static final String MD_BUTTON_OK		= "OK";

// TransFrame
public static final String TF_NUM_NEAR_AND_GLOSSARY	= 
	"{0,number,integer} concordances difuses and {1,number,integer} " +
	"termes del glossari";
public static final String TF_NUM_GLOSSARY			=
	"S'han trobat {0,number,integer} termes del glossari";
public static final String TF_NUM_NEAR				=
	"S'han trobat {0,number,integer} concordances difuses";
public static final String TF_FUZZY		= "Concordances difuses...";
public static final String TF_GLOSSARY		= "Termes del glossari";
public static final String TF_SRCTEXT		= "Text origen";
public static final String TF_TRANSLATION	= "Traducci�";
public static final String TF_SCORE		= "Puntuaci�";
public static final String TF_WARNING		= "Av�s";
public static final String TF_ERROR		= "Error";
public static final String TF_NONE		= "--cap--";
public static final String TF_MENU_FILE		= "Fitxer";
public static final String TF_MENU_FILE_OPEN	= "Obri";
public static final String TF_MENU_FILE_CREATE	= "Crea un projecte nou";
public static final String TF_MENU_FILE_CLOSE	= "Tanca";
public static final String TF_MENU_FILE_COMPILE	= "Compila";
public static final String TF_MENU_FILE_PROJWIN	= "Mostra llista de fitxers";
public static final String TF_MENU_FILE_MATCHWIN	= "Mostra finestra de concordan�a";
public static final String TF_MENU_FILE_SAVE	= "Guarda";
public static final String TF_MENU_FILE_QUIT	= "Surt";
public static final String TF_MENU_EDIT		= "Edita";
public static final String TF_MENU_EDIT_UNDO	= "Desf�s (Z)";
public static final String TF_MENU_EDIT_REDO	= "Ref�s (Y)";
public static final String TF_MENU_EDIT_NEXT	= "Entrada seg�ent";
public static final String TF_MENU_EDIT_PREV	= "Entrada anterior";
public static final String TF_MENU_EDIT_NEXT_UNTRANS	= "Seg�ent sense traduir";
public static final String TF_MENU_EDIT_FIND	= "Busca";
//public static final String TF_MENU_EDIT_FINDEXACT	= "Find exact (target)";
public static final String TF_MENU_EDIT_INSERT
			= "Insereix traducci�";
public static final String TF_MENU_EDIT_RECYCLE
			= "Recicla traducci�";
public static final String TF_MENU_EDIT_GOTO	= "V�s a l'entrada";
public static final String TF_MENU_EDIT_COMPARE_1
			= "Compara concordan�a difusa #1";
public static final String TF_MENU_EDIT_COMPARE_2
			= "Compara concordan�a difusa #2";
public static final String TF_MENU_EDIT_COMPARE_3
			= "Compara concordan�a difusa #3";
public static final String TF_MENU_EDIT_COMPARE_4
			= "Compara concordan�a difusa #4";
public static final String TF_MENU_EDIT_COMPARE_5
			= "Compara concordan�a difusa  #5";
public static final String TF_MENU_DISPLAY			= "Configuraci�";
//public static final String TF_MENU_DISPLAY_FUZZY	= "Fuzzy Match info";
//public static final String TF_MENU_DISPLAY_GLOSSARY	= "Glossary";
public static final String TF_MENU_DISPLAY_SOURCE	= "Text origen";
public static final String TF_MENU_DISPLAY_FONT	= "Tipus de lletra";
public static final String TF_MENU_DISPLAY_ADVANCE	= "Useu TAB per avan�ar";
public static final String TF_MENU_DISPLAY_MNEMONIC	= "Mostra mnem�nics";
//public static final String TF_MENU_SERVER	= "Server";
//public static final String TF_MENU_LANGUAGE	= "Language";
//public static final String TF_MENU_LANGUAGE_RESCAN	= "rescan";
public static final String TF_MENU_TOOLS		= "Eines";
public static final String TF_MENU_TOOLS_PSEUDO	= "Pseudo-tradueix";
public static final String TF_MENU_TOOLS_VALIDATE	= "Valida Etiquetes";
public static final String TF_MENU_TOOLS_MERGE_TMX	= "Fusiona fitxersTMX";
public static final String TF_MENU_VERSION_HELP		= "Ajuda";
public static final String TF_TITLE		= "OmegaT";
public static final String TF_SELECT_LANGUAGE_TITLE	=
			"Elegiu llengua";
public static final String TF_SELECT_LANGUAGE	=
			"Per favor, elegiu llengua";
public static final String TF_SELECT_LANGUAGE_FAILED	=
		"No heu indicat una llengua. Se us n'elegeix una.";
public static final String TF_TM_LOAD_ERROR	=
			"No s'ha pogut carregar la mem�ria de traducci� del projecte.";
public static final String TF_LOAD_ERROR	=
			"No s'ha pogut carregar el projecte especificat.";
public static final String TF_COMPILE_ERROR	=
			"No s'ha pogut compilar els fitxers del projecte.";
//public static final String TF_SEARCH		= "Keyword search (source)";
//public static final String TF_SEARCH_EXACT	= "Exact search (target)";
//public static final String TF_CUR_STRING
//		= "Segment {0,number,integer} of {1,number,integer}";
//public static final String TF_NUM_WORDS		=
//	"{0,number,integer} of {2,number,integer}" +
//	" words left ({1,number,integer})";
//public static final String TF_GOTO_ENTRY	= "Goto string:";
public static final String TF_BUTTON_OK		= "OK";
public static final String TF_BUTTON_CANCEL	= "Cancel�la";
public static final String TF_FUZZY_CURRENT_PROJECT	= 
		"Projecte actual";
public static final String TF_PSEUDOTRANS_RUSURE_TITLE	= "Av�s";
public static final String TF_PSEUDOTRANS_RUSURE	=
	"Aquesta operaci� crea traduccions falses per a\n" +
	"totes les cadenes del projecte actual i no es pot\n" +
	"desfer.  De veritat que voleu continuar?";
public static final String TF_NUM_FUZZY_MATCHES	=
	"S'han trobat {0,number,integer} concordances difuses";
public static final String TF_NUM_FUZZY_MATCH	=
	"S'ha trobat 1 concordan�a difusa";
public static final String TF_NOTICE_BAD_TAGS	= "Entrades amb etiquetes modificades";
public static final String TF_NOTICE_OK_TAGS	= "No s'han detectat errors d'etiquetes";
public static final String TF_NOTICE_TITLE_TAGS	= "Validant etiquetes";
// NOTE: segment start is assumed to contain "0000" string to overwrite
//	with entry number.  If zeros not detected, entry number will not be
//	displayed
public static final String TF_CUR_SEGMENT_START		= "<segment 0000> ";
public static final String TF_CUR_SEGMENT_END		= " <final segment>";
public static final String TF_SELECT_SOURCE_FONT	= "Tipus de lletra";
public static final String TF_SELECT_FONTSIZE		= "Grand�ria";
//public static final String TF_SELECT_TARGET_FONT	= "Target font";
public static final String TF_SELECT_FONTS_TITLE	= "Seleccioneu tipus de lletra de visualitzaci�";
public static final String TF_BAD_LOCATION_POSSIBLE_CORRUPTION =
	"S'ha trobat un error potencialment seri�s. El motor sembla haver perdut" + 
	"sincronisme amb els camps de text de la interf�cie d'�s. S'avorta l'execuci� i " +
	"el programa s'estavella per evitar la corrupci�.";
public static final String TF_LOADING_FILE			= "Carregant fitxer: ";
public static final String TF_MATCH_VIEWER_TITLE	= 
	"Visor de concordances i de glossari";
public static final String TF_NO_MORE_UNTRANSLATED	= 
	"No hi ha m�s cadenes sense traduir";

// ContextFrame
public static final String CF_SEARCH_RESULTS_SRC	= 
	"Resultats de la recerca en la llengua origen per a: ";
public static final String CF_SEARCH_RESULTS_LOC	= 
	"Resultats en la llengua meta per a: ";
public static final String CF_BUTTON_CLOSE	= "Tanca";

// Project frame
public static final String PF_BUTTON_CLOSE	= "Tanca";
public static final String PF_WINDOW_TITLE	= "Fitxers del projecte";
public static final String PF_FILENAME		= "Nom de fitxer";
public static final String PF_NUM_SEGMENTS	= "Nombre de segments";

public static final String HF_BUTTON_CLOSE	= "Tanca";
public static final String HF_BUTTON_HOME	= "�ndex";
public static final String HF_BUTTON_BACK	= "Arrere";
public static final String HF_WINDOW_TITLE	= "Manual d'�s";
public static final String HF_CANT_FIND_HELP	= "No es troba el fitxer d'ajuda: ";

// CommandThread
public static final String CT_FUZZY_X_OF_Y	=
"Analitzant cadenes - fetes {0,number,integer} de {1,number,integer}";
public static final String CT_TM_X_OF_Y	=
"Analitzant la mem�ria de traducci� - {0,number,integer} de {1,number,integer}";

public static final String CT_LOADING_PROJECT	= "Carregant projecte";
public static final String CT_LOADING_INDEX	= "Construint fitxers d'�ndex";
public static final String CT_LOADING_GLOSSARY	= "Carregant glossari";
public static final String CT_LOADING_FUZZY	= "Carregant taules difuses";
public static final String CT_CANCEL_LOAD = "C�rrega de projecte avortada";
public static final String CT_LOADING_WORDCOUNT	= "Construint comptes de mots";
public static final String CT_ERROR_SAVING_PROJ	= 
		"Error en  guardar el fitxer de projecte";
public static final String CT_ERROR_WRITING_NEARLOG	= 
		"S'ha trobat un error en escriure el fitxer dif�s";
public static final String CT_ERROR_CREATE	= 
		"Errorr en crear el projecte";
public static final String CT_FATAL_ERROR	= 
	"Error fatal: guardant el projecte amb l'extensi� de reserva '" + 
	OConsts.STATUS_RECOVER_EXTENSION + "' .\n" +
	"  Per favor, consulteu la documentaci� sobre les opcions de recuperaci� \n" +
	"  i retorneu la informaci� de m�s avall a l'autor del programari amb \n" +
	"  una descripci� de com s'ha produ�t aquest error.\n";
public static final String CT_DONT_RECOGNIZE_GLOS_FILE =
	"No puc recon�ixer el fitxer de glossari: ";
public static final String CT_ERROR_LOADING_HANDLER_FILE =
	"S'ha trobat un error en carregar el fitxer de correspond�ncies d'extensions\n " +
	"S'ignoren les instruccions de maneig.";
public static final String CT_ERROR_FINDING_HANDLER_FILE =
	"Av�s: no s'ha pogut trobar el fitxer de correspond�ncies d'extensions.";
public static final String CT_ERROR_FINDING_IGNORE_FILE =
	"Av�s: no s'ha pogut trobar el fitxer d'omissi�.";
public static final String CT_ERROR_LOADING_IGNORE_FILE =
	"S'ha trobat un error en carregar el fitxer d'omissi�. e\nNo es tindran en compte les instruccions d'omissi�";
public static final String CT_NO_FILE_HANDLER =
	"No puc associar un analitzador per a l'extensi� de fitxer";
public static final String CT_PREF_LOAD_ERROR_MAPPINGS =
	"Error intern (problemes en recuperar les correspond�ncies de fitxers a partir del fitxer de prefer�ncies)";
public static final String CT_HTMLX_MASQUERADE	=
	"He trobat un fitxer HTML basat en XML - usar� l'analitzador HTMLX";
public static final String CT_LOAD_FILE_MX	= "Carregant: ";
public static final String CT_COMPILE_FILE_MX	= "Compilant: ";
public static final String CT_COMPILE_DONE_MX	= "Ha acabat la compilaci�";
public static final String CT_COPY_FILE	= "Copiant fitxer";

// ProjectProperties
public static final String PP_CREATE_PROJ	= "Crea un projecte nou";
public static final String PP_PROJ_ROOT		= "Directori arrel del projecte: ";
public static final String PP_PROJ_INTERNAL		= "Fitxers de projecte d'OmegaT: ";
public static final String PP_SRC_ROOT		= "Directori arrel dels fitxers origen: ";
public static final String PP_LOC_ROOT		= "Directori arrel dels fitxers tradu�ts: ";
public static final String PP_GLOS_ROOT		= "Directori arrel dels glossaris:";
public static final String PP_TM_ROOT		= "Directori arrel de les mem�ries de traducci�:";
public static final String PP_SRC_LANG		= 
		"Llengua origen (p.e. EN-US, EN, ES-NI, DE, etc)";
public static final String PP_LOC_LANG		= 
		"Llengua meta (p.e. DE-DE, EN-IE, ES, EN, etc)";
public static final String PP_BUTTON_OK		= "OK";
public static final String PP_BUTTON_CANCEL	= "Cancel�la";
public static final String PP_BUTTON_ADVANCED	= "Edita els camins";
public static final String PP_PROJECT_NAME		= "Nom del projecte";
public static final String PP_BUTTON_BROWSE_SRC		= "Canvia origen";
public static final String PP_BUTTON_BROWSE_TAR		= "Canvia meta";
public static final String PP_BUTTON_BROWSE_GL		= "Canvia glossaris";
public static final String PP_BUTTON_BROWSE_TM		= "Canvia MT";
public static final String PP_BUTTON_SELECT		= "Seleccioneu";
public static final String PP_BROWSE_TITLE_SOURCE	= "Seleccioneu el directori origen";
public static final String PP_BROWSE_TITLE_TARGET	= "Seleccioneu el directori meta";
public static final String PP_BROWSE_TITLE_GLOS	= "Seleccioneu el directori de glossaris";
public static final String PP_BROWSE_TITLE_TM	= 
	"Seleccioneu el directori de les mem�ries de traducci�";
public static final String PP_MESSAGE_BADLANG	=
	"Els codis de llengua especificats s�n inv�lids (TMX requereix codis correctes)";
public static final String PP_MESSAGE_BADPROJ	=
	"Sembla que alguns directoris del projecte s'han mogut. Per favor, trobeu-los.";
public static final String PP_MESSAGE_CONFIGPROJ	=
	"Especifiqueu directoris personalitzats de projecte aqu�.";
public static final String PP_SAVE_PROJECT_FILE	=
	"Crea un nou projecte";
public static final String PP_DEFAULT_PROJECT_NAME = "omegat.proj";
//public static final String PP_OMEGAT_PROJ_FILE	= "OmegaT project (.proj)";

// LogDisplay
public static final String LD_WARNING		= "Av�s:";
public static final String LD_ERROR		= "ERROR";

// HandlerMaster
public static final String HM_MISSING_DIR	= 
		"No s'ha trobat el directori del projecte";

// ProjectFileChooser
public static final String PFC_OMEGAT_PROJECT	= "directori del projecte OmegaT";

// NewFileChooser 
public static final String NDC_SELECT_UNIQUE	=
	"Aquest nom de fitxers ja existeix. Per favor, seleccioneu-ne un altre.";
public static final String NDC_SELECT_UNIQUE_TITLE	= "Error";

// FileHandler
public static final String FH_ERROR_WRITING_FILE	= 
		"Error en escriure el fitxer d'eixida compilat";

public static final String SW_SEARCH_TEXT	= "Buscar: ";
public static final String SW_WORD_SEARCH	= "Recerca de mot clau";
public static final String SW_SEARCH		= "Recerca";
public static final String SW_EXACT_SEARCH	= "Recerca exacta";
public static final String SW_SEARCH_TM		= "Recerca les TM";
public static final String SW_LOCATION		= "Localitzaci�";
public static final String SW_BROWSE		= "Seleccioneu directori";
public static final String SW_DIR_SEARCH	= "Buscar fitxers";
public static final String SW_DIR_RECURSIVE	= "Recerca recursiva";
public static final String SW_TITLE		= "Recerca de text";
public static final String SW_DISMISS		= "Descartar finestra";
public static final String SW_BUTTON_SELECT	= "Selecciona";
public static final String SW_VIEWER_TEXT	=
	"Les recerques exactes busquen la cadena especificada en l'�mbit del " +
	"projecte actual o en qualsevol directori o arbre de directoris. La recerca exacta " +
	"permet l'�s dels  j�quers '*' i '?'.  El car�cter " +
	"'*' representa zero o m�s car�cters (el terme de recerca 'cas*' " +
	"trobaria 'cas', 'casa', i 'casament', per exemple).  " +
	"El car�cter '?' representa exactament un car�cter ('cas?' " +
	"trobaria 'casa' i 'casc', per exemple, per� no 'cas' o " +
	"'casament').  Aquesta operaci� busca tant en la llengua origen " +
	"com en la llengua meta.\n\n" +
	"Les recerques de mot clau examinen el text origen i presenten tots els " +
	"segments que contenen tots els mots indicats, en qualevol ordre. Aquesta " +
	"operaci� nom�s es pot fer sobre el text origen de projectes carregats.\n\n" + 
	"M�s detalls en la documentaci�";
public static final String SW_MAX_FINDS_REACHED	= 
	"S'ha arribat al m�xim (" + OConsts.ST_MAX_SEARCH_RESULTS + 
	") nombre de resultat de recerca.";

public static final String ST_FILE_SEARCH_ERROR =
	"Errors buscant l'arbre de directoris";
public static final String ST_FATAL_ERROR = 
	"La seq��ncia de recerca s'ha mort inesperadament - per favor, tanqueu la finestra de recerca";
public static final String ST_NOTHING_FOUND = "La recerca no ha trobat res";

public static final String TF_INTRO_MESSAGE = 
	"Benvinguts a OmegaT\n";
//	"Welcome to OmegaT.\n\nTo begin a new translation project, select " +
//	"'" + TF_MENU_FILE_CREATE + "' from the file menu and select a " +
//	"place to save the new project.  During project creation, you will " + 
//	"be prompted to select several folder locations - using the default " +
//	"values should work just fine (but feel free to change these if you " +
//	"so desire).\nAfter creating the project, unzip or copy your source " +
//	"files into your project's \"source\" directory and put whatever TMX " +
//	"files you have available to you in the \"tm\" folder.  Then you are " +
//	"ready to open your project.";
};
