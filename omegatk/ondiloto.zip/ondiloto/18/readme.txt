ondiloto (ONline DIctionary LOokup TOol)

Version: alpha 18

Licence:

Copyright (C) 2007, Marc Prior

This program is free software; you may redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License (GPL) for more details.

A copy of the GNU General Public License should be available from the source from which you obtained this program; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

Marc Prior
lin4trans@users.sourceforge.net
www.marcprior.de

Ondiloto and other OmegaTk applications are subject to ABSOLUTELY NO WARRANTY
This is free software, and you are welcome to redistribute it under certain conditions; please refer to the GPL for details


Requirements:

* Linux (uses the primary selection; to work on Windows, modify the script to use the clipboard - this does however involve more keystrokes, which largely defeats the object)
* tcl/tk
* w3m (Linux). A Windows version of w3m or a Windows alternative, if one exists, is required for Windows.


Configuration (Linux/KDE):

ondiloto.tcl and w3m must be in the execution path.

If the wish executable is not at /usr/bin/wish, edit the first line.

In order for ondiloto to be launched from the keyboard from within any application, create a system-wide shortcut to launch it. Instructions for KDE:

Control Center > Desktop > Panels > Menus > Edit K Menu

Create a new menu item in a suitable location. 
Name: ondiloto
Command: ondiloto.tcl
Click on "Current shortcut key" to select a suitable shortcut, i.e. one that is not already in use. I used Alt-Q. 


Usage:

Highlight the term to be queried, then hit the selected shortcut.

If all is working properly, a tk window will appear containing the output from the queried dictionary. To query a different dictionary, simply select the corresponding radiobutton.

Hit Esc to close the window.


Adaptation:

To add further dictionaries, add a new procedure and a new radiobutton for each procedure. 


Issues:

As usual, my coding skills. :-)

The code is very repetitive, but this does make it easier for those with no knowledge of tcl/tk to understand and modify. When I know what direction this is going in (if any), this is likely to change.

Only suitable for querying online dictionaries which are accessed by a URL containing the query term.

Routines to strip most of the garbage from the dictionary outputs (or to access them properly where dedicated protocols exist) could be added to the procedures.

Non-ascii characters are not encoded properly (yet).

And probably lots more
